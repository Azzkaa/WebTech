module.exports = {
  transpileDependencies: [],
  devServer: {
    proxy: 'http://localhost:3000'
  }
}
