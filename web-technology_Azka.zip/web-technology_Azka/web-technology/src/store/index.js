import { createStore } from 'vuex'

// store/index.js

export default createStore({
    state: {
      profile: {
        name: 'Azka Aftab',
        courseYear: '3/SECK',
        matrixNo: '123',
        address: 'Your Address',
      }
    },
    mutations: {
      resetProfile(state) {
        state.profile = {
          name: 'Azka Aftab',
          courseYear: '3/SECK',
          matrixNo: '123',
          address: 'Your Address',
        };
      }
    },
    actions: {
      resetProfileAction({ commit }) {
        commit('resetProfile');
      }
    },
    getters: {
      getProfile(state) {
        return state.profile;
      }
    }
  });
  