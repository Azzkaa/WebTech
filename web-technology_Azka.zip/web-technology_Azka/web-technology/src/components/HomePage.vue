<template>
    <div>
      <CourseContent />
    </div>
  </template>
  
  <script>
  import CourseContent from './CourseContent.vue';
  
  export default {
    name: 'HomePage',
    components: {
      CourseContent,
    },
  };
  </script>
  
  <style>
  /* Add your styles here */
  </style>
  